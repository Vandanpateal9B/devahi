import React,{useState} from 'react';
import './App.scss';
import { Routes, Route } from 'react-router-dom';
import Home from './components/Home/Home';
import Event from './components/Events/EventPage/Event';
import EventDetails from './components/Events/EventPage/EventDetails';
import Venues from './components/Venues/Venues';
import VenueDetails from './components/Venues/VenueDetails'
import Search from './components/Search/Search';
import SignIn from './components/AuthPages/SignIn/SignIn';
import SignUp from './components/AuthPages/SingUp/SingUp';
import AboutUs from './components/AboutUs/AboutUs'
import ContactUs from './components/ContactUs/ContactUs'
import UltimateGuide from './components/UltimateGuide/UltimateGuide'
import PrivacyPolicy from './components/PrivacyPolicy/PrivacyPolicy';
import ForgotPassword from './components/AuthPages/SignIn/ForgotPassword';
import { SmallCardProvider } from './components/Events/SmallCard/SmallCardContext';
import { VenueProvider } from './components/Venues/VenueContext';
import OtpVerify from './components/AuthPages/OtpVerify/OtpVerify';
import Profile from './components/AuthPages/Profile/Profile'
function App() {
  
  return (
    <>
      <SmallCardProvider>
      <VenueProvider>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/events" element={<Event/>} />
        <Route path="/event-details/:eventId" element={<EventDetails/>}/>
        <Route path="/venues" element={<Venues />} />
        <Route path="/venue-details/:venueId" element={<VenueDetails/>}/>
        <Route path="/search" element={<Search/>}/>
        <Route path="/sign-in" element={<SignIn />} />
        <Route path="/sign-up" element={<SignUp />} />
        <Route path="/profile" element={<Profile/>} />
        <Route path= "forgot-password" element = {<ForgotPassword/>} />
        <Route path= "otp-verify" element = {<OtpVerify/>} />
        <Route path="/about-us" element={<AboutUs />} />
        <Route path="/contact-us" element={<ContactUs/>} />
        <Route path="/ultimate-guide" element={<UltimateGuide/>} />
        <Route path="/privacy-policy" element={<PrivacyPolicy/>} />
      </Routes>
      </VenueProvider>
      </SmallCardProvider>
    </>
  )
}

export default App;