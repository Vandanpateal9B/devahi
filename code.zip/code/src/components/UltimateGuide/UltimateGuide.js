import React from 'react'
import Header from '../Header/Header'
import Footer from '../Footer/Footer'

function UltimateGuide() {
  return (
    <div>
      <Header/>
      <Footer/>
    </div>
  )
}

export default UltimateGuide
