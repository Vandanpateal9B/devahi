import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Slider.scss';
import { Carousel } from 'react-responsive-carousel';
import 'react-responsive-carousel/lib/styles/carousel.min.css';
import ServerName from '../config';
import Loading from '../Loading';
import { useNavigate, NavLink } from 'react-router-dom';

const getFirstNWords = (text, n) => {
  const words = text.split(' ');
  return words.slice(0, n).join(' ');
};

const containerStyle = {
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  height: '100%',
};

const SlickSlider = () => {
  const [slides, setSlides] = useState([]);
  const [loading, setLoading] = useState(false);
  const [currentSlide, setCurrentSlide] = useState(0);
  const navigate = useNavigate();

  useEffect(() => {
    setLoading(true);
    axios
      .get(ServerName() + '/api/web/get_featured_events_list')
      .then((response) => {
        setSlides(response.data.data);
        setLoading(false);
      })
      .catch((error) => {
        console.error('Error fetching data:', error);
        setLoading(false);
      });
  }, []);



  const handleSlideChange = (index) => {
    setCurrentSlide(index);
  };

  return (
    <div className='banner'>
      <div className='container'>
        <div className='banner-slider'>
          {loading ? (
            <div style={containerStyle}>
              <Loading />
            </div>
          ) : (
            slides.length > 0 && (
              <Carousel
                showThumbs={false}
                showStatus={false}
                autoPlay={true}
                infiniteLoop={true}
                interval={3000}
                transitionTime={500}
                showArrows={false}
                showIndicators={true}
                selectedItem={currentSlide}
                onChange={handleSlideChange}
                swipeable={true} // Enable cursor slide control
              >
                {slides.map((slide, index) => {
                  const numWordsToShow = slide.title.split(' ').length > 2 ? 10 : 20;
                  return (
                    <div className='banner-slide position-relative' key={index}>
                      <img src={slide.image} alt={slide.title} />
                      <div className='banner-details'>
                        <h1 className='banner-title'>{slide.title}</h1>
                        <p className='banner_text'>{getFirstNWords(slide.description, numWordsToShow)}....</p>
                        <div className='pt-4'>
                          <NavLink className='banner-btn' to={`/event-details/${slide.id}`}>
                            View More
                          </NavLink>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </Carousel>
            )
          )}
          {slides.length > 0 && (
            <div className='dots'>
              {slides.map((_, index) => (
                <div
                  key={index}
                  className={`dot ${index === currentSlide ? 'active' : ''}`}
                  onClick={() => setCurrentSlide(index)}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SlickSlider;

