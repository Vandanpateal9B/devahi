import React, { createContext, useContext, useState } from 'react';
import './VenueDetails.scss'
const VenueContext = createContext();

export const VenueProvider = ({ children }) => {
  const [venueData, setVenueData] = useState(() => {
    const storedVenueData = localStorage.getItem('venueData');
    return storedVenueData ? JSON.parse(storedVenueData) : null;
  });
  const setVenue = (data) => {
    setVenueData(data);
    localStorage.setItem('venueData', JSON.stringify(data));
  };  
  return (
    <VenueContext.Provider value={{ venueData, setVenue }}>
      {children}
      
    </VenueContext.Provider>
  );
};

export const useVenueContext = () => {
  return useContext(VenueContext);
};
