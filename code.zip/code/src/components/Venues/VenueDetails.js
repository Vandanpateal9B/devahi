import React, { useState, useEffect } from 'react';
import './VenueDetails.scss'
import '../../_varibles.scss'
import 'react-datepicker/dist/react-datepicker.css';
import axios from 'axios';
import Loading from '../Loading'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faMapMarkerAlt } from '@fortawesome/free-solid-svg-icons';
import ServerName from '../config';
import { useNavigate, useParams } from 'react-router-dom';
import Footer from '../Footer/Footer';
import Header from '../Header/Header';

import { useVenueContext } from './VenueContext';

export default function Event() {
  const { venueData } = useVenueContext();
  console.log("VenueData", venueData)
  const { venueId } = useParams();
  const [VenueDetailsData, setVenueDetailsData] = useState(null);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const containerStyle = {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100vh',

  };


  useEffect(() => {
    const fetchEventDetails = async () => {
      try {
        if (venueId) {
          const response = await axios.get(
            `${ServerName()}/api/web/get_events_by_venue?venue_id=${venueId}`
          );
          setVenueDetailsData(response.data.data);
          setLoading(false);
        }
      } catch (error) {
        console.error('Error fetching data:', error);
        setLoading(false);
      }
    };

    fetchEventDetails();
  }, [venueId]);


  const handleEventClick = (eventId) => {
    navigate(`/event-details/${eventId}`);
  };


  if (!VenueDetailsData) {
    return (
      <div style={containerStyle}>
        <Loading />
      </div>
    );
  }


  return (
    <div>
      <Header />
       <div className='venue-banner'>
        <div className='container'>
          <div className='venue-banner_slider'>
            {venueData && (
              <div className='venue-banner_slide d-flex'>
                <div className='venue-banner_details '>
                  <img src={venueData.image} alt="Venue" className='venue-banner_details-img'/>
                  <div className='position-absolute venue-bannre-location'>
                  <h1 className='venue-banner_title text-white'>{venueData.name}</h1>
                  <p className='venue-banner_text text-white'>
                  <FontAwesomeIcon icon={faMapMarkerAlt} className='post-location-icon pe-2' />{venueData.address}</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className='venue'>
        <div className='container'>
          <div className='venue-slider-navbar row'></div>
          <div className='venue-card'>
            {loading ? (
              <div style={containerStyle}>
                <Loading />
              </div>
            ) : (
              <div className='venue-post row'>
                {VenueDetailsData !== null && Array.isArray(VenueDetailsData) && VenueDetailsData.length > 0 ? (
                  VenueDetailsData.map((venue, index) => (
                    <div className='col-xxl-3 col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 p-3' key={index}>
                      <div className='text-bg-light venue-post-details h-100' onClick={() => handleEventClick(venue.id)}>
                        <div className='venue-img'>
                          <img src={venue.image} className='w-100'/>
                        </div>
                        <div className='venue-information'>
                          <a className='location text-decoration-none d-flex'>
                          <FontAwesomeIcon icon={faMapMarkerAlt} className='post-location-icon pe-2' /> {venue.location}
                          </a>
                          <p className='post-description pe-2 mb-0'>
                            <a className='text-decoration-none'>
                              {venue.title}
                            </a>
                          </p>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className='col-12 text-center'>No Events Found</div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      <Footer />
    </div>
  )
}
