import React, { useState, useEffect, useRef } from 'react';
import './SmallCard.scss'
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import '../../../_varibles.scss'
import 'react-datepicker/dist/react-datepicker.css';
import axios from 'axios';

import all_events from '../../../assets/img/all_event.svg';
import Slider from 'react-slick';
import Loading from '../../Loading'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faMapMarkerAlt } from '@fortawesome/free-solid-svg-icons';
import ServerName from '../../config';
import { settings, SmallCardAfter, EventBtn, containerStyle } from '../../ContainerStyle';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useSmallCard } from './SmallCardContext';

export default function SmallCard() {
  const { events, setEvents, categories, showAllEvents } = useSmallCard();
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [selectedFilter, setSelectedFilter] = useState('all');
  const [loading, setLoading] = useState(false);
  const [selectedCategories, setSelectedCategories] = useState([]);

  const navigate = useNavigate();
  const location = useLocation();


  const dateInputRef = useRef(null);
  const handleFilterChange = async (filter, category_id) => {
    setLoading(true);
    try {
      let updatedSelectedCategories = [...selectedCategories];

      if (category_id === 'all') {
        updatedSelectedCategories = []; // Clear other categories when 'all' is selected
      } else {
        if (selectedCategories.includes('all')) {
          updatedSelectedCategories = [category_id]; // Clear 'all' and select the new category
        } else {
          if (updatedSelectedCategories.includes(category_id)) {
            updatedSelectedCategories = updatedSelectedCategories.filter(id => id !== category_id);
          } else {
            updatedSelectedCategories.push(category_id);
          }
        }
      }

      setSelectedCategories(updatedSelectedCategories);

      if (updatedSelectedCategories.length === 0) {
        setSelectedCategories(['all']); // If no categories are selected, select 'all'
      }

      const categoryQueryString = updatedSelectedCategories.includes('all') ? '' : updatedSelectedCategories.join(',');
      const url = ServerName() + `/api/web/get_events_list?filter_by_day=${filter}&category_id=${categoryQueryString}`;

      const response = await axios.get(url);

      setEvents(response.data.data);
      setSelectedFilter(filter);
      setLoading(false);
      // dateInputRef.current.value = '';
    } catch (error) {
      console.error('Error fetching data:', error);
      setLoading(false);
    }
  };

  useEffect(() => {
    setSelectedCategories(['all']); // Set 'all' category as initially selected
    handleFilterChange(selectedFilter, 'all'); // Apply the selected filter and 'all' category
  }, []);



  const FetchByDate = async (selectedDate) => {
    try {
      const response = await axios.get(ServerName() + `/api/web/get_home_page_events_list`, {
        params: {
          filter_by_date: selectedDate
        },
      });
      return response.data.data;
    } catch (error) {
      console.error('Error fetching data:', error);
      throw error;
    }
  };
  const handleDateChange = async (event) => {
    const selectedDate = event.target.value;
    try {
      setLoading(true);
      setSelectedFilter('');
      // setSelectedCategories(['all']);
      const data = await FetchByDate(selectedDate);
      setEvents(data);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching data:', error);
      setLoading(false);
    }
  };

  const renderCategories = () => {
    if (!Array.isArray(categories) || categories.length === 0) {
      return <p></p>;
    }
    return categories.map((category) => (
      <a
        className={`catigare py-4 d-flex flex-column text-center align-items-center border rounded text-decoration-none ${selectedCategories.includes(category.id) ? 'active' : ''}`}
        onClick={() => handleFilterChange(selectedFilter, category.id)}
      >
        <img src={category.image_path} className='event_img' alt="" />
        <p className='catigare-name pt-2 m-0'>{category.name}</p>
      </a>
    ));

  };

  const handleEventClick = (eventId) => {
    navigate(`/event-details/${eventId}`);
  };

  const handleButtonClick = () => {
    navigate('/events');
  };

  return (
    <div className='event'>
      <div className='container'>
        <div className='event-slider-navbar  row'>
          <SmallCardAfter className='section-title position-relative col-xxl-2 col-xl-12'>
            <h2 className='ps-3'>Events</h2>
          </SmallCardAfter>
          <div className='slider-menu d-flex justify-content-end align-items-center col-xxl-10 col-xl-12 mt-xxl-0 mt-md-4'>
            <div className='select-date d-flex align-items-center'>
              <label className='pe-3'>Select Date:</label>
              <div>
                <input type='date' ref={dateInputRef} onChange={handleDateChange} />
              </div>
            </div>
            <div className="form-floating mb-4 d-flex">
            </div>
            <div className='filter d-flex align-items-center'>
              <label className='px-3'>Filter By:</label>
              <ul className='filter-tabs d-flex align-items-center m-0 p-2'>
                <li
                  className={`px-4 py-2 mx-1 ${selectedFilter === 'today' ? 'active' : ''}`}
                  onClick={() => handleFilterChange('today')}
                >
                  Today
                </li>
                <li
                  className={`px-4 py-2 mx-1 ${selectedFilter === 'week' ? 'active' : ''}`}
                  onClick={() => handleFilterChange('week')}
                >
                  This Week
                </li>
                <li
                  className={`px-4 py-2 mx-1 ${selectedFilter === 'weekend' ? 'active' : ''}`}
                  onClick={() => handleFilterChange('weekend')}
                >
                  This Weekend
                </li>
                <li
                  className={`px-4 py-2 mx-1 ${selectedFilter === 'month' ? 'active' : ''}`}
                  onClick={() => handleFilterChange('month')}
                >
                  This Month
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div className='cards'>
          <div className=''>
            <Slider {...settings} className='smallcard'>
              {showAllEvents && (
                <a
                  className={`catigare px-2 py-4 mx-sm-auto h-100  d-flex flex-column text-center align-items-center border rounded text-decoration-none ${selectedCategories.includes('all') ? 'active' : ''}`}
                  onClick={() => handleFilterChange(selectedFilter, 'all')}
                >
                  <img src={all_events} className='event-img' alt='All Events' />
                  <p className='catigare-name pt-2 m-0'>All Events</p>
                </a>

              )}
              {renderCategories()}
            </Slider>
          </div>
        </div>
        <div className='events'>
          {loading ? <div style={containerStyle}><Loading /></div> : (
            <div className='event-post row'>
              {Array.isArray(events) && events.length > 0 ? (
                events.map((event) => (
                  <div className=' col-xxl-3 col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 p-3 '
                    
                    onClick={() => handleEventClick(event.id)}
                  >
                    <div className='text-bg-light event-post-details h-100' >
                      <div className='event-img'>
                        <img src={event.image} className='w-100' />
                      </div>
                      <div className='event-information'>
                        <a className='location text-decoration-none d-flex ' href='#'>
                          <FontAwesomeIcon icon={faMapMarkerAlt} className='post-location-icon pe-2' /><span> {event.location}</span>
                        </a>
                        <p className='post-description pe-2 mb-0'>
                          <a className='text-decoration-none' href='#'>{event.title}</a>
                        </p>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className='col-12 text-center '>No Events Found</div>
              )}
            </div>
          )}
          <EventBtn className='d-flex justify-content-center position-relative'>
            <a href='#' className='eventbtn text-decoration-none' onClick={handleButtonClick}> All Events</a>
          </EventBtn>
        </div>
      </div>
    </div>
  )
}

