import React, { createContext, useContext, useState, useEffect } from 'react';
import axios from 'axios';
import ServerName from '../../config';

const SmallCardContext = createContext();

export function SmallCardProvider({ children }) {
  const [events, setEvents] = useState([]);
  const [categories, setCategories] = useState(['all']);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [showAllEvents, setShowAllEvents] = useState(false); 
  const [defaultFilter, setDefaultFilter] = useState('all');


  const fetchAllEvents = async () => {
    try {
      const response = await axios.get(ServerName()+ '/api/web/get_home_page_events_list');
      return response.data.data;
    } catch (error) {
      console.error('Error fetching data:', error);
      throw error;
    }
  };

  const fetchByCategories = async () => {
    try {
      const response = await axios.get(ServerName() + '/api/web/get_categories_list');
      return response.data.data;
    } catch (error) {
      console.error('Error fetching data:', error);
      throw error;
    }
  };

  useEffect(() => {
    setLoading(true);
    const fetchData = async () => {
      try {
        const [categoriesData, eventsData] = await Promise.all([fetchByCategories(), fetchAllEvents()]);
        setShowAllEvents(true); 
        setCategories(categoriesData);
        setEvents(eventsData);
        setLoading(false);
      } catch (error) {
        setError('Error fetching data. Please try again later.');
        setLoading(false);
      }
    };
    fetchData();
    return () => {
      // Check if the location state indicates event navigation
      if (!window.history.state?.state?.eventNavigation) {
        setDefaultFilter('all');
      }
    };
  }, []);

  const contextValue = { events, setEvents, categories, setCategories, showAllEvents};

  return (
    <SmallCardContext.Provider value={contextValue}>
      {children}
    </SmallCardContext.Provider>
  );
}

export function useSmallCard() {
  return useContext(SmallCardContext);
}
