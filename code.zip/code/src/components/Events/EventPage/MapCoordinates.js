import React from 'react';
const MapCoordinates = ({ latitude, longitude  }) => {
    const zoom = 20;
    return (
        <div className='event-map'>
             <iframe
                src={`https://maps.google.com/maps?q=${latitude},-${longitude}&z=${zoom}&output=embed`}
                width="100%"
                height="400"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="google map"
            >
            </iframe>

        </div>
    );
};

export default MapCoordinates;
