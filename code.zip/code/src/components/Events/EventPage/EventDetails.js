import React, { useState, useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import ServerName from '../../config';
import axios from 'axios';
import Header from '../../Header/Header';
import Footer from '../../Footer/Footer';
import './EventDetails.scss';
import Loading from '../../Loading';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faInfoCircle, faChevronRight, faLocationDot, faClock, faWallet } from '@fortawesome/free-solid-svg-icons';
import MapCoordinates from './MapCoordinates';


function truncateAddress(address, maxLength) {
  if (address.length <= maxLength) {
    return address;
  }
  return `${address.slice(0, maxLength)} ...`;
}


function truncateLink(link, maxLength) {
  if (link.length <= maxLength) {
    return link;
  }
  const truncatedLink = link.substring(0, maxLength);
  return `${truncatedLink} ...`;
}

function formatDate(date) {
  const options = { weekday: 'long', month: 'long', day: 'numeric' };
  return date.toLocaleDateString('en-US', options);
}

export default function EventDetails() {

  const { eventId } = useParams();

  const [eventDetailsData, setEventDetailsData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchEventDetails = async () => {
      try {
        const response = await axios.get(ServerName() + `/api/web/event_detail`, {
          params: {
            event_id: eventId,
          },
        });
        setEventDetailsData(response.data.data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching data:', error);
        setLoading(false);
      }
    };
    if (eventId) {
      fetchEventDetails();
    }
  }, [eventId]);

  const containerStyle = {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100vh',
  };

  if (!eventDetailsData) {
    return (
      <div style={containerStyle}>
        <Loading />
      </div>
    );
  }

  const formatTimeRange = (startTime, endTime) => {
    if (!startTime || !endTime) return '';
    const formatTime = (timeString) => {
      const [time, amPM] = timeString.split(' ');
      const [hours, minutes] = time.split(':').map(Number);
      const twelveHourFormat = hours % 12 || 12;
      const timeFormat = amPM || (hours >= 12 ? 'PM' : 'AM');
      return `${twelveHourFormat}:${minutes.toString().padStart(2, '0')} ${timeFormat}`;
    };
    return `${formatTime(startTime)} - ${formatTime(endTime)}`;
  };

  const EventAddress = truncateAddress(eventDetailsData?.venue_details?.address, 30);

  const maxLinkLength = 30;
  const EventLink = truncateLink(eventDetailsData?.link, maxLinkLength);
  const formattedEventDate = formatDate(new Date(eventDetailsData.event_date));

  const src = `https://www.google.com/maps?q=${eventDetailsData.venue_details.latitude},-${eventDetailsData.venue_details.longitude}`;

  return (
    <div>
      <Header />
      <section className='eventdetails'>
        <div className='container'>
          <div className='event-information'>
            <div className='event-img'>
              <div className='event-details row'>
                <div className=' col-xxl-8 col-xl-8 col-lg-8 col-md-12 col-sm-12'>
                  <img src={eventDetailsData.image} className='event-banner ' />
                </div>
                <div className='col-xl-4 col-xxl-4 col-lg-4 col-md-12 col-sm-12  text-white'>
                  <div className='more-info-links p-4'>
                    <a href={eventDetailsData.link} target='_blank' className='text-decoration-none'>
                      <button className='info-btn btn d-flex justify-content-center mx-auto text-white align-items-center gap-2 w-100 fs-5'>
                        <FontAwesomeIcon icon={faInfoCircle} />  MORE INFO
                      </button>
                    </a>
                    <div className='d-flex flex-lg-column justify-content-between row'>
                      <Link className='links link-details d-flex align-items-center gap-1 border-bottom py-2 pb-3 text-decoration-none' href={src}
                        target='_blank'>
                        <FontAwesomeIcon icon={faLocationDot} style={{ color: "#ffffff", }} className='event-info-icon me-3 fs-3 mt-2' />
                        <div>
                          <a href={src} target='_blank' className='text-decoration-none text-white pb-2'>
                            <h5 className="pt-2">{eventDetailsData.venue_details.name}</h5>
                            {EventAddress}
                          </a>
                        </div>

                        <a href={src} target='_blank' className='ms-auto text-white'>
                          <FontAwesomeIcon icon={faChevronRight} className="ms-auto fs-3 pe-3" />
                        </a>
                      </Link>
                      <div className='links  d-flex align-items-center gap-1 border-bottom py-2 pb-3'>
                        <FontAwesomeIcon icon={faClock} style={{ color: "#ffffff", }} className='event-info-icon me-3 fs-3 mt-2' />
                        <div>
                          <h5 className='pt-2'>{formattedEventDate}</h5>
                          <a href="#" className="text-decoration-none text-white pb-2">
                            {formatTimeRange(eventDetailsData.start_time, eventDetailsData.end_time)}
                          </a>
                        </div>
                      </div>
                      <Link className='links link-details  d-flex align-items-center gap-1 py-2 text-decoration-none' href={eventDetailsData.link} target='_blanck'>

                        <FontAwesomeIcon icon={faWallet} style={{ color: "#ffffff", }} className='event-info-icon me-3 fs-3 mt-2' />
                        <div>
                          <a href={eventDetailsData.link} target='_blanck' className='text-decoration-none text-white pb-2'>
                            <h5 className="pt-2">{eventDetailsData.type}</h5>
                            {EventLink}
                          </a>
                        </div>
                        <a href={eventDetailsData.link} target='_blanck' className='ms-auto text-white'>
                        <FontAwesomeIcon icon={faChevronRight} className='ms-auto fs-3 pe-3' />
                        </a>
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="event-title pb-5">
              <h2>{eventDetailsData.title}</h2>
            </div>
            <p className='event-description col-12'>{eventDetailsData.description}</p>
          </div>
          <div className='d-flex align-items-center justify-content-center gap-5'></div>
        </div>
      </section>
      <div className='event-map'>
        <MapCoordinates
          latitude={eventDetailsData.venue_details.latitude}
          longitude={eventDetailsData.venue_details.longitude}
        />
      </div>
      <Footer />
    </div>
  );
}
