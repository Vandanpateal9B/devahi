import React, { useState, useEffect } from 'react';
import './Footer.scss';
import { NavLink } from "react-router-dom";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faFacebook, faTwitter, faLinkedin, faInstagram, faYoutube } from '@fortawesome/free-brands-svg-icons';
import { library } from '@fortawesome/fontawesome-svg-core';
library.add(faFacebook, faTwitter, faLinkedin, faInstagram, faYoutube);


export default function Footer() {
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());

  useEffect(() => {
    setCurrentYear(new Date().getFullYear());
  }, []);

  return (
    <div className='footer'>
      <div className='container'>
        <div className='footer-menus d-flex justify-content-between flex-lg-row flex-md-column flex-column'>
          <ul className='footer-menu d-flex align-items-center gap-4 justify-content-lg-start justify-content-sm-center'>
            <li><NavLink href='#' className='text-decoration-none text-white' to="/about-us">About Us </NavLink></li>
            <li><NavLink href='#' className='text-decoration-none text-white' to="/contact-us"> Contact Us</NavLink></li>
            <li><NavLink href='#' className='text-decoration-none text-white' to="/ultimate-guide"> Ultimate User Guide</NavLink></li>
            <li><NavLink href='#' className='text-decoration-none text-white' to="/privacy-policy">Privacy Policy </NavLink></li>
          </ul>
          <ul className='d-flex align-items-center justify-content-lg-end justify-content-sm-center justify-content-center gap-4'>
            <li className='footer-icone'><a href='#' className='btn text-white fs-5 '><FontAwesomeIcon icon={faFacebook} /></a></li>
            <li className='footer-icone'><a href='#' className='btn text-white fs-5 '> <FontAwesomeIcon icon={faTwitter} /></a></li>
            <li className='footer-icone'><a href='#' className='btn text-white fs-5 '><FontAwesomeIcon icon={faLinkedin} /></a></li>
            <li className='footer-icone'><a href='#' className='btn text-white fs-5 '><FontAwesomeIcon icon={faInstagram} /></a></li>
            <li className='footer-icone'><a href='#' className='btn text-white fs-5 '><FontAwesomeIcon icon={faYoutube} /></a></li>
          </ul>
        </div>
        <div className='copyright text-center'>
        <p className='m-0'>© {currentYear} 405 live All Rights Reserved</p>
        </div>
      </div>
    </div>
  )
}
