const ServerName = () => {
  return  'http://54.157.131.155:8080';
  // return  'http://192.168.0.160:8080';
  // return  `${window.location.protocol}//${window.location.hostname}:8080`;
  };
  
  export default ServerName;