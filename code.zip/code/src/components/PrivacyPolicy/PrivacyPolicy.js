import React, { useEffect, useState } from 'react';
import Header from '../Header/Header';
import Footer from '../Footer/Footer';
import axios from 'axios';
import ServerName from '../config';
import { SmallCardAfter, containerStyle } from '../ContainerStyle';
import Loading from '../Loading';

function PrivacyPolicy() {
  const [privacyContent, setPrivacyContent] = useState('');
  const [loading, setLoading] = useState(true);

  const fetchPrivacy = async () => {
    try {
      const response = await axios.get(ServerName()+'/api/web/get_privacy_policy');
      setPrivacyContent(response.data.data);
      setLoading(false); // Set loading to false after data is fetched
    } catch (error) {
      console.error('Error fetching data:', error);
      setLoading(false); // Also set loading to false in case of error
      throw error;
    }
  };

  useEffect(() => {
    fetchPrivacy();
  }, []);

  const paragraphs = privacyContent.split('<p></p>');

  return (
    <>
      <Header/>
      <div className='container'>
        <div className="privacy-content mt-5">            
          <SmallCardAfter className='section-title position-relative col-xxl-2 col-xl-12'>
            <h2 className='ps-3 mb-5'>Privacy Policy</h2>
          </SmallCardAfter>
          {loading ? <div style={containerStyle}><Loading /></div> : (
            paragraphs.map((paragraph, index) => (
              <div key={index} className="paragraph" dangerouslySetInnerHTML={{ __html: paragraph }} />
            ))
          )}
        </div>
      </div>
      <Footer/>
    </>
  );
}

export default PrivacyPolicy;
