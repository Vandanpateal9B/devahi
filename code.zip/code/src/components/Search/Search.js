import React, { useState, useEffect, useRef } from 'react';
import '../Events/EventPage/Event.scss'
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import '../../_varibles.scss'
import 'react-datepicker/dist/react-datepicker.css';
import axios from 'axios';
import styled from 'styled-components';
import Animation from '../../assets/img/titledesigen.svg';
import all_events from '../../assets/img/all_event.svg';
import Slider from 'react-slick';
import Loading from '../Loading'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faMapMarkerAlt } from '@fortawesome/free-solid-svg-icons';
import ServerName from '../config';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import { settings, SmallCardAfter, containerStyle } from '../ContainerStyle';

import Footer from '../Footer/Footer';
import Header from '../Header/Header';

export default function Search() {
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const searchTerm = searchParams.get('query');
  const [events, setEvents] = useState([]);
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [selectedFilter, setSelectedFilter] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [selectedDate, setSelectedDate] = useState(null);
  const [showAllEvents, setShowAllEvents] = useState(false);
  const [selectedCategories, setSelectedCategories] = useState([]);

  const navigate = useNavigate();



  const FetchBySearchTerm = async (searchTerm) => {
    try {
      const response = await axios.get(ServerName() + '/api/web/get_home_page_events_list', {
        params: {
          search: searchTerm, // Change 'query' to 'search'
        },
      });
      return response.data.data;
    } catch (error) {
      console.error('Error fetching data:', error);
      throw error;
    }
  };

  useEffect(() => {
    setLoading(true);
    const fetchData = async () => {
      try {
        if (searchTerm) {
          const eventsData = await FetchBySearchTerm(searchTerm);
          setEvents(eventsData);
        }
        setLoading(false);
      } catch (error) {
        setError('Error fetching data. Please try again later.');
        setLoading(false);
      }
    };
    fetchData();
  }, [searchTerm]);


  const FetchByDate = async (selectedDate, searchTerm) => {
    try {
      const response = await axios.get(ServerName() + `/api/web/get_home_page_events_list`, {
        params: {
          filter_by_date: selectedDate,
          search: searchTerm,
        },
      });
      return response.data.data;
    } catch (error) {
      console.error('Error fetching data:', error);
      throw error;
    }
  };


  const dateInputRef = useRef(null);

  // const handleFilterChange = async (filter, category_id) => {
  //   setLoading(true);
  //   try {
  //     setSelectedCategory(category_id);
  //     setSelectedFilter(filter);

  //     let url = ServerName()+ `/api/web/get_home_page_events_list`;
  //     const params = {
  //       filter_by_day: filter,
  //     };

  //     if (category_id === 'all') {
  //       params.search = searchTerm;
  //     }else if (category_id) {
  //       params.category_id = category_id;
  //     }

  //     if (searchTerm) {
  //       params.search = searchTerm;
  //     }

  //     const response = await axios.get(url, { params });
  //     setEvents(response.data.data);
  //     setLoading(false);
  //     dateInputRef.current.value = '';
  //   } catch (error) {
  //     console.error('Error fetching data:', error);
  //     setLoading(false);
  //   }
  // };

  // useEffect(() => {
  //   setSelectedCategory('all');// Reset selected category when the filter changes
  //   setSelectedDate('');
  // }, [selectedFilter]);

  const handleFilterChange = async (filter, category_id) => {
    setLoading(true);
    try {
      let updatedSelectedCategories = [...selectedCategories];
      if (category_id === 'all') {
        updatedSelectedCategories = ['all']; // Always keep 'all' as selected
      } else {
        if (selectedCategories.includes('all')) {
          updatedSelectedCategories = [category_id]; // Clear 'all' and select the new category
        } else {
          if (updatedSelectedCategories.includes(category_id)) {
            updatedSelectedCategories = updatedSelectedCategories.filter(id => id !== category_id);
          } else {
            updatedSelectedCategories.push(category_id);
          }
        }
      }

      setSelectedCategories(updatedSelectedCategories);

      if (updatedSelectedCategories.length === 0) {
        setSelectedCategories(['all']); // If no categories are selected, select 'all'
      }

      const categoryQueryString = updatedSelectedCategories.includes('all') ? '' : updatedSelectedCategories.join(',');
      const url = ServerName() + `/api/web/get_events_list?search=${searchTerm}&filter_by_day=${filter}&category_id=${categoryQueryString}`;


      const response = await axios.get(url);

      setEvents(response.data.data);
      setSelectedFilter(filter);
      setLoading(false);
      dateInputRef.current.value = '';
    } catch (error) {
      console.error('Error fetching data:', error);
      setLoading(false);
    }
  };

  useEffect(() => {
    setSelectedDate('');
    setSelectedCategories(['all']); // Set 'all' category as initially selected
    handleFilterChange(selectedFilter, 'all'); // Apply the selected filter and 'all' category
  }, []);



  const handleDateChange = async (event) => {
    const selectedDate = event.target.value;
    try {
      setLoading(true);

      if (searchTerm) {
        const data = await FetchByDate(selectedDate, searchTerm);
        setEvents(data);
      } else {
        setEvents([]);
      }

      setLoading(false);
    } catch (error) {
      console.error('Error fetching data:', error);
      setLoading(false);
    }
  };

  const fetchByCategories = () => {
    return axios
      .get(ServerName() + '/api/web/get_categories_list')
      .then((response) => {
        return response.data.data;
      })
      .catch((error) => {
        console.error('Error fetching data:', error);
        throw error;
      });
  };


  useEffect(() => {
    setLoading(true);
    const fetchData = async () => {
      try {
        const [categoriesData, eventsData] = await Promise.all([fetchByCategories()]);
        setCategories(categoriesData);
        setShowAllEvents(true);
        setLoading(false);
      } catch (error) {
        setError('Error fetching data. Please try again later.');
        setLoading(false);
      }
    };
    fetchData();
  }, []);



  const renderCategories = () => {
    if (!Array.isArray(categories) || categories.length === 0) {
      return <p></p>;
    }
    return categories.map((category) => (
      <a
        key={category.id}
        className={`catigare py-4 d-flex flex-column text-center align-items-center border rounded text-decoration-none ${selectedCategories.includes(category.id) ? 'active' : ''}`}
        onClick={() => handleFilterChange(selectedFilter, category.id)}
      >
        <img src={category.image_path} className='event_img' alt="" />
        <p className='catigare-name pt-2 m-0'>{category.name}</p>
      </a>
    ));
  };


  const handleEventClick = (eventId) => {
    navigate(`/event-details/${eventId}`);
  };

  return (
    <>
      <Header />
      <div className='event'>
        <div className='container'>
          <div className='event-slider-navbar  row'>
            <SmallCardAfter className='section-title position-relative col-xxl-2 col-xl-12'>
              <h2 className='ps-3'>Events</h2>
            </SmallCardAfter>
            <div className='slider-menu d-flex justify-content-end align-items-center col-xxl-10 col-xl-12 mt-xxl-0 mt-md-4'>
              <div className='select-date d-flex align-items-center'>
                <label className='pe-3'>Select Date:</label>
                <div>
                  <input type='date' ref={dateInputRef} onChange={handleDateChange} />
                </div>
              </div>
              <div className="form-floating mb-4 d-flex">
              </div>
              <div className='filter d-flex align-items-center'>
                <label className='px-3'>Filter By:</label>
                <ul className='filter-tabs d-flex align-items-center m-0 p-2'>
                  <li
                    className={`px-4 py-2 mx-1 ${selectedFilter === 'today' ? 'active' : ''}`}
                    onClick={() => handleFilterChange('today')}
                  >
                    Today
                  </li>
                  <li
                    className={`px-4 py-2 mx-1 ${selectedFilter === 'week' ? 'active' : ''}`}
                    onClick={() => handleFilterChange('week')}
                  >
                    This Week
                  </li>
                  <li
                    className={`px-4 py-2 mx-1 ${selectedFilter === 'weekend' ? 'active' : ''}`}
                    onClick={() => handleFilterChange('weekend')}
                  >
                    This Weekend
                  </li>
                  <li
                    className={`px-4 py-2 mx-1 ${selectedFilter === 'month' ? 'active' : ''}`}
                    onClick={() => handleFilterChange('month')}
                  >
                    This Month
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className='cards'>
            <div className=''>
              <Slider {...settings} className='smallcard'>
                {showAllEvents && (
                  <a
                    className={`catigare px-2 py-4 mx-sm-auto h-100  d-flex flex-column text-center align-items-center border rounded text-decoration-none ${selectedCategories.includes('all') ? 'active' : ''}`}
                    onClick={() => handleFilterChange(selectedFilter, 'all')}
                  >
                    <img src={all_events} className='event-img' alt='All Events' />
                    <p className='catigare-name pt-2 m-0'>All Events</p>
                  </a>
                )}
                {renderCategories()}
              </Slider>
            </div>
          </div>
          <div className='events'>
            {loading ? <div style={containerStyle}><Loading /></div> : (
              <div className='event-post row'>
                {Array.isArray(events) && events.length > 0 ? (
                  events.map((event, index) => (
                    <div className=' col-xxl-3 col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 p-3 ' key={event.id}>
                      <div className='text-bg-light event-post-details h-100' onClick={() => handleEventClick(event.id)} >
                        <div className='event-img'>
                          <img src={event.image} className='w-100' alt={event.title} />
                        </div>
                        <div className='event-information'>
                          <a className='location text-decoration-none' href='#'>
                            <FontAwesomeIcon icon={faMapMarkerAlt} className='post-location-icon pe-2' /> {event.location}
                          </a>
                          <p className='post-description pe-2 mb-0'>
                            <a className='text-decoration-none' href='#'>{event.title}</a>
                          </p>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className='col-12 text-center '>No Events Found</div>
                )}
              </div>
            )}
          </div>

        </div>
      </div>
      <Footer />
    </>
  )
}
