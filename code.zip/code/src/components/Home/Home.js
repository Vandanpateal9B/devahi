import React from 'react';
import Header from '../Header/Header'
import Slider from '../Slider/Slider';
import SmallCard from '../Events/SmallCard/SmallCard';
import Feature from '../Feature/Feature';
import AdSlider from '../AdSlider/AdSlider';
import Footer from '../Footer/Footer';
function Home() {
  return (
    <>
      <Header />
      <Slider />
      <SmallCard />
      <Feature />
      <AdSlider />
      <Footer />
    </>
  )
}
export default Home