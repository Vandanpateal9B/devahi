import React, { useState, useEffect } from 'react'
import Header from '../../Header/Header';
import Footer from '../../Footer/Footer';
import logo from '../../../assets/img/logo192.png';
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import { useNavigate, Link } from 'react-router-dom';
import ServerName from '../../config';

function Profile() {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [old_password, setOldPassword] = useState('');
    const [new_password, setNewPassword] = useState('');
    const [confirm_password, setConfirmPassword] = useState('')
    const [Birthdate, setBirthdate] = useState('');
    const [showPasswordFields, setShowPasswordFields] = useState(false);
    const navigate = useNavigate();
    const [userProfileData, setuserProfileData] = useState('');

    const token = localStorage.getItem('token'); // Assuming you store the token in localStorage

    const fetchProfile = async () => {
        try {
            const response = await axios.get(ServerName() + '/api/web/get_user', {
                headers: {
                    Authorization: `Bearer ${token}`, // Include the token in the header
                },
            });
            setuserProfileData(response.data.data);
            setName(response.data.data.name);
            setEmail(response.data.data.email_address);
            setBirthdate(response.data.data.birthdate);
        } catch (error) {
            console.error('Error fetching data:', error);
            throw error;
        }
    };

    useEffect(() => {
        fetchProfile();
    }, [token]); // Fetch profile whenever the token changes


    const handleSubmit = async (e) => {
        e.preventDefault();
        const updatedData = {
            name: name,
            email: email,
            birthdate: Birthdate,
            email_address: email,
            old_password: old_password,
            new_password: new_password,
        };

        try {
            const response = await axios.post(ServerName() + '/api/web/update_profile', updatedData, {
                headers: {
                    Authorization: `Bearer ${token}`, // Include the token in the headers
                },
            });

            if (response.data.success) {
                toast.success('Profile updated successfully.', {
                    position: toast.POSITION.TOP_RIGHT,
                    autoClose: 2000,
                });
            }
            await new Promise((resolve) => setTimeout(resolve, 2000));
            navigate('/')
        } catch (error) {
            toast.error('An error occurred while updating profile.', {
                position: toast.POSITION.TOP_RIGHT,
                autoClose: 2000,
            });
        }
    };

    return (
        <>
            <Header />
            <div className='mx-auto  '>
                <div className='sign d-flex w-100 align-item-center justify-content-center'>
                    <div className='bg-white sign-right'>
                        <div className='sign-form animated-form '>
                            <div className="text-center">
                                <h4 className="mt-5 mb-3 pb-1"> Profile</h4>
                            </div>
                            <form onSubmit={handleSubmit}>
                                <div className='sign-email'>
                                    <label htmlFor='text'>Enter your name: </label>
                                    <input type='text' name='name' placeholder='example@gmail.com' value={name} onChange={(e) => setName(e.target.value)} />
                                </div>
                                <div className='sign-email'>
                                    <label htmlFor='text'>Enter your Birthdate: </label>
                                    <input
                                        type='date'
                                        name='birthdate'
                                        placeholder='example@gmail.com'
                                        value={Birthdate}
                                        onChange={(e) => setBirthdate(e.target.value)}
                                        max={new Date().toISOString().split('T')[0]}
                                    />
                                </div>
                                <div className='sign-email'>
                                    <label htmlFor='email'>Email: </label>
                                    <input
                                        type='email'
                                        name='email'
                                        placeholder='example@gmail.com'
                                        value={email}
                                        onChange={(e) => setEmail(e.target.value)}
                                        disabled />
                                </div>
                                <div className='d-flex justify-content-between remember-forgot'>
                                    <span className='mt-2'>
                                        <a className='text-decoration-none d-flex' >
                                            <input
                                                type="checkbox"
                                                className='chekbox me-2'
                                                onChange={() => setShowPasswordFields(!showPasswordFields)}
                                            />Change password ?</a>
                                    </span>
                                </div> 
                                <br></br>
                                {showPasswordFields && (
                                    <>

                                        <div className='sign-pass'>
                                            <label htmlFor='passw'>Old password: </label>
                                            <input type='password' name='passw' value={old_password} onChange={(e) => setOldPassword(e.target.value)} />
                                        </div>
                                        <div className='sign-pass'>
                                            <label htmlFor='passw'>New password: </label>
                                            <input type='password' name='passw' value={new_password} onChange={(e) => setNewPassword(e.target.value)} />
                                        </div>
                                        <div className='sign-pass'>
                                            <label htmlFor='passw'> Confirm password: </label>
                                            <input type='password' name='passw' value={confirm_password} onChange={(e) => setConfirmPassword(e.target.value)} />
                                        </div>
                                    </>
                                )}
                                <button className='sign-btn' type='submit'>Submit<ToastContainer /></button>
                                <div className='singn-up-width text-center mt-2'>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <Footer />
        </>
    )
}

export default Profile
