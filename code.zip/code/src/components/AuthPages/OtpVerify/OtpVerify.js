import React,{useState} from 'react'
import Header from '../../Header/Header'
import Footer from '../../Footer/Footer'
import logo from '../../../assets/img/logo192.png';
import axios from 'axios';
import ServerName from '../../config';
import { useNavigate } from 'react-router-dom';

function OtpVerify() {
    const [OTPinput, setOTPinput] = useState('');
    const [error, setError] = useState(null);
  
   const navigate = useNavigate();

   const verifyOTP = async () => {
    try {
        const response = await axios.post(ServerName()+'/api/web/verify_otp', { otp: parseInt(OTPinput) });
        if (response.data.success) {
            navigate("/sign-in"); 
        } else {
            setError("Invalid OTP. Please enter the correct OTP.");
        }
    } catch (error) {
        setError("An error occurred while verifying OTP. Please try again later.");
    }
};

  return (
    <>
      <Header/>
      <div className='mx-auto '>
        <div className='sign d-flex w-100'>
          <div className=' text-center sign-left forgot-pass d-flex flex-column align-items-center justify-content-center'>
            <h3 className='login-title mt-5'> Hey There! Welcome 405 </h3>
            <div className='login-logo'>
              <img src={logo} />
            </div>
          </div>
          <div className='bg-white sign-right forgot-pass'>
            <div className='sign-form animated-form '>
              <div className="text-center">
                <h4 className="mt-5 mb-3 pb-1"> Verify Otp</h4>
              </div>
              <form>
                <div className='sign-email'>
                  <label htmlFor='email'>Enter your otp: </label>
                  <input type='number' name='otp' placeholder='Enter 6 digit your otp' value= {OTPinput} onChange={(e) => setOTPinput(e.target.value)} />
                </div>
                <button className='sign-btn' type='submit' onClick={() => verifyOTP()} >Verify Otp</button>
              </form>
            </div>
          </div>
        </div>
      </div>
      <Footer/>
    </>
  )
}

export default OtpVerify
