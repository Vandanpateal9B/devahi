import React,{useState} from "react";
import { LoginSocialGoogle } from "reactjs-social-login";
import google from '../../../assets/img/login-google.svg';
import axios from "axios";
import ServerName from "../../config";
import {  useNavigate } from "react-router-dom";

function GoogleSignIn() {
  const navigate = useNavigate()
  const sendUserDataToBackend = async (userData) => {
    // console.log("Before sending to backed", userData)
    try {
      const response = await fetch('http://192.168.0.160:8080/api/web/social_login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(userData),
      });
      const responseData = await response.json();
      console.log("After Sending to backend Api", responseData.data);
      navigate('/');
    } catch (error) {
      console.error('Google login error:', error);
    }
  };
  return (
    <div>
      <LoginSocialGoogle
         client_id={"539050299211-hhbs877c3v7oabu9qvspdlpgsalm78gq.apps.googleusercontent.com"}
        scope="openid profile email"
        discoveryDocs="claims_supported"
        access_type="offline"
        onResolve={({ provider, data }) => {
          const userData = {
            email: data.email,
            name: data.name,
            birthday: data.birthday,
            user_type: 'google'
          };
          sendUserDataToBackend(userData);
        }}
        onReject={(err) => {
          console.log(err);
        }}
      >
        <a href= "#" className='text-decoration-none py-3 px-4 border rounded-1'><img src={google}/></a>
      </LoginSocialGoogle>
      
    </div>
  );
}

export default GoogleSignIn;

