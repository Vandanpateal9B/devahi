// import React from 'react';
// import Header from '../Header/Header';
// import Footer from '../Footer/Footer';
// import GoogleSignIn from './GoogleSignIn'; 
// import axios from 'axios';

// const SocialSign = () => {
//   const handleGoogleLoginSuccess = async (idToken) => {
//     try {
//       // Now you can send this ID token to your backend for verification
//       // and creation/authentication of user.
//       const response = await axios.post('http://192.168.0.160:8080/api/web/social_login', { idToken });
//       // Handle the response from your backend accordingly.
//     } catch (error) {
//       console.error('Google login error:', error);
//     }
//   };

//   const handleGoogleLoginFailure = (error) => {
//     console.error('Google login failure:', error);
//   };


//   return (
//     <>
//       <Header />

//       <div className='login-with-btn my-4 d-flex gap-2 justify-content-center'>
//         <GoogleSignIn
//           onGoogleLoginSuccess={handleGoogleLoginSuccess}
//           onGoogleLoginFailure={handleGoogleLoginFailure}
//         />
//       </div>
//       <Footer />
//     </>
//   );
// };

// export default SocialSign;






// import React, { useState, useEffect } from 'react';
// // import { googleLogout, useGoogleLogin } from '@react-oauth/google';
// import axios from 'axios';
// import { useNavigate,Link ,useLocation} from 'react-router-dom';

// function SocialSign() {
//   const location = useLocation();
//   const token = new URLSearchParams(location.search).get('token');
//     const [ user, setUser ] = useState([]);
//     const [ profile, setProfile ] = useState([]);

//     // const login = useGoogleLogin({
//     //     onSuccess: (codeResponse) => setUser(codeResponse),
//     //     onError: (error) => console.log('Login Failed:', error)
//     // });
//     useEffect(
//         () => {
//             if (user) {
//                 axios
//                     .get(`https://www.googleapis.com/oauth2/v1/userinfo?token=${token}`, {
//                         headers: {
//                             Authorization: `Bearer ${token}`,
//                             Accept: 'application/json'
//                         }
//                     })
//                     .then((res) => {
//                         setProfile(res.data);
//                     })
//                     .catch((err) => console.log(err));
//             }
//         },
//         [ user ]
//     );

//     // log out function to log the user out of google and set the profile array to null
//     // const logOut = () => {
//     //     googleLogout();
//     //     setProfile(null);
//     // };

//     return (
//         <div>
//             <h2>React Google Login</h2>
//             <br />
//             <br />
//             {profile ? (
//                 <div>
//                     <h3>User Logged in</h3>
//                     <p>Name: {profile.name}</p>
//                     <p>Email Address: {profile.email}</p>
//                     <br />
//                     <br />
//                     {/* <button onClick={logOut}>Log out</button> */}
//                 </div>
//             ) : (
//                 <button >Sign in with Google 🚀 </button>
//             )}
//         </div>
//     );
// }
// export default SocialSign;



// import React from 'react';

// import FacebookLogin from 'react-facebook-sdk';
// import google from '../../assets/img/login-google.svg';
// import { LoginSocialGoogle } from "reactjs-social-login";

// const SocialSign = () => { {

//     const responseFacebook = (response) => {
//       console.log(response);
//     }

//     const responseGoogle = (response) => {
//       console.log(response);
//     }

//     return (
//       <div className="App">
//         <h1>LOGIN WITH FACEBOOK AND GOOGLE</h1>

//         <FacebookLogin
//         appId=""
//         autoLoad={false}
//         fields="name,email,picture"
//         callback={responseFacebook}
//       />
//       <br />
//       <br />


//       <LoginSocialGoogle
//         client_id={"539050299211-hhbs877c3v7oabu9qvspdlpgsalm78gq.apps.googleusercontent.com"}
//         scope="openid profile email"
//         discoveryDocs="claims_supported"
//         access_type="offline"
//         onResolve={({ provider, data }) => {
//           console.log(provider, data);
//         }}
//         onReject={(err) => {
//           console.log(err);
//         }}
//       >
//          <a className='text-decoration-none py-2 px-4 border rounded-1'><img src={google}/></a>
//      </LoginSocialGoogle>
//       </div>
//     );
//   }
// }

// export default SocialSign;