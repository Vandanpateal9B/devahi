import React, { createContext, useContext, useState, useEffect } from 'react';
import axios from 'axios';
// import { googleLogout, useGoogleLogin } from '@react-oauth/google';
const GoogleOAuthContext = createContext();

export const useGoogleOAuth = () => {
  return useContext(GoogleOAuthContext);
};

export const GoogleOAuthProvider = ({ children }) => {

    const [user, setUser] = useState([]);
    const [profile, setProfile] = useState([]);


    const handleGoogleSignIn = async (token) => {
        console.log("code ",token)
        try {
          const response = await axios.post('http://192.168.0.160:8080/api/web/social_login', {
            authorization_code: token, 
          });
          const userData = response.data.data;
          setUser(userData);
          console.log('User:', userData);
        } catch (error) {
          console.error('Google login error:', error);
        }
      };



useEffect(() => {
    if (user && user.token) {
      fetchUserProfile(user.token);
    }
  }, [user]);

  const fetchUserProfile = (accessToken) => {
    axios
      .get(`https://www.googleapis.com/oauth2/v1/userinfo?access_token=${accessToken}`)
      .then((res) => {
        setProfile(res.data);
      })
      .catch((err) => console.log(err));
  };


//   const login = useGoogleLogin({
//       onSuccess: (codeResponse) => setUser(codeResponse),
//       onError: (error) => console.log('Login Failed:', error)
//   });
  // log out function to log the user out of google and set the profile array to null
//   const logOut = () => {
//     googleLogout();
//     setProfile(null);
//   };


  const value = {
    handleGoogleSignIn,
    user,
    profile,
    // login,
    // logOut,
  };

  return (
    <GoogleOAuthContext.Provider value={value}>
      {children}
    </GoogleOAuthContext.Provider>
  );
};
