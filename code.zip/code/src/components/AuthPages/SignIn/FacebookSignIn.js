import React, { useEffect } from 'react';
import facebook from '../.././/../assets/img/login-facebook.svg';
// import { configureFacebookSDK } from './FacebookConfig';

const FacebookSignIn = () => {
  const handleFacebookLogin = async () => {
    try {
      const response = await new Promise((resolve, reject) => {
        window.FB.login(
          function (response) {
            if (response.authResponse) {
              resolve(response.authResponse);
            } else {
              reject(response);
            }
          },
          { scope: 'public_profile,email' }
        );
      });

      console.log('Facebook Login Response:', response);
      const userData = {
        email: response.email,
        name: response.name,
        user_type: 'facebook'
      };
      sendUserDataToBackend(userData)
      // Handle authentication and user data here
    } catch (error) {
      console.error('Facebook Login Error:', error);
      // Handle error
    }
  };
  // useEffect(() => {
  //   configureFacebookSDK('619806210060864');
  // }, []);

  const sendUserDataToBackend = async (userData) => {
    console.log("Data from facebook before backend Api :", userData);
    try {
      const response = await fetch('http://192.168.0.160:8080/api/web/social_login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(userData),
      });

      const responseData = await response.json();
      console.log("Data Inside Backend API:", responseData);
    } catch (error) {
      console.error('Backend API error:', error);
    }
  };

  useEffect(() => {
    window.fbAsyncInit = function () {
      window.FB.init({
        appId: '619806210060864',
        cookie: true,
        xfbml: true,
        version: 'v15.0'
      });
    };
  
    (function (d, s, id) {
      var js,
        fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) return;
      js = d.createElement(s);
      js.id = id;
      js.src = 'https://connect.facebook.net/en_US/sdk.js';
      fjs.parentNode.insertBefore(js, fjs);
    })(document, 'script', 'facebook-jssdk');
  }, []);
  
  // ...
  
  return (
    <div>
      <a href ="#" className='text-decoration-none py-3 px-4 border rounded-1' onClick={handleFacebookLogin} ><img src={facebook}/></a>
    </div>
  );
};

export default FacebookSignIn;

