import React, { useState, useEffect } from 'react';
import Header from '../../Header/Header';
import Footer from '../../Footer/Footer';
import axios from 'axios';
import './Sign.scss';
import logo from '../../../assets/img/logo192.png';
import 'react-toastify/dist/ReactToastify.css';
import ServerName from '../../config';
import GoogleSignIn from './GoogleSignIn';
import FacebookSignIn from './FacebookSignIn';
import { ToastContainer, toast } from 'react-toastify';
import { useNavigate, Link } from 'react-router-dom';


const SignIn = () => {
  const navigate = useNavigate();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const handleSubmit = async (e) => {
    e.preventDefault();
    const items = {
      email: email,
      password: password,
    };

    try {
      const response = await axios.post(ServerName() + '/api/web/login', items);
      if (response.data.success) {
        const token = response.data.data.token;
        axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
        localStorage.setItem('token', token);
        console.log("Token:", token);
        setIsLoggedIn(true);
        toast.success('Login Successfully.', {
          position: toast.POSITION.TOP_RIGHT,
          autoClose: 2000,
        });
        await new Promise((resolve) => setTimeout(resolve, 2000));
        navigate('/');
      }
      else {
        toast.error(response.data.message, {
          position: toast.POSITION.TOP_RIGHT,
          autoClose: 2000,
        });
      }
      setEmail('');
      setPassword('');
    } catch (error) {
      toast.error('An error occurred while logging in.', {
        position: toast.POSITION.TOP_RIGHT,
        autoClose: 2000,
      });
    }
  };


  return (
    <>
      <Header />
      <div className='mx-auto '>
        <div className='sign d-flex w-100'>
          <div className=' text-center sign-left d-flex flex-column align-items-center justify-content-center'>
            <h3 className='login-title mt-5'> Hey There! Welcome 405 </h3>
            <div className='login-logo'>
              <img src={logo} />
            </div>
            <span className='text-center mb-5'>Don't have an account? <Link href='#' className='text-decoration-none fw-bold' to="/sign-up">Sign Up</Link></span>
          </div>
          <div className='bg-white sign-right'>
            <div className='sign-form animated-form '>
              <div className="text-center">
                <h4 className="mt-5 mb-3 pb-1"> Sign In</h4>
              </div>
              <form onSubmit={handleSubmit}>
                <div className='sign-email'>
                  <label htmlFor='email'>Email: </label>
                  <input type='email' name='email' placeholder='example@gmail.com' value={email} onChange={(e) => setEmail(e.target.value)} />
                </div>
                <div className='sign-pass'>
                  <label htmlFor='passw'>Password: </label>
                  <input type='password' name='passw' value={password}
                    onChange={(e) => setPassword(e.target.value)} />
                  <div className='d-flex justify-content-between remember-forgot'>
                    <span className='mt-2'>
                      <a className='text-decoration-none d-flex' href='#'> <input type="checkbox" className='chekbox me-2' /> Remember Me</a>
                    </span>
                    <span className='mt-2'><Link className='text-decoration-none' to='/forgot-password'>Forgot Password?</Link></span>
                  </div>
                </div>
                <button className='sign-btn' type='submit'>Login <ToastContainer /></button>
                <div className='singn-up-width text-center mt-2'>
                  <h6 className='text-center mt-3'>
                    <span href='#' className=' '>Or Login with</span></h6>
                  <div className='login-with-btn my-4 d-flex gap-2  justify-content-center'>
                    <FacebookSignIn />
                    <GoogleSignIn />
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
}

export default SignIn;