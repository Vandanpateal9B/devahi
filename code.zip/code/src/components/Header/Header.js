import React, { useState, useEffect } from 'react';
import './Header.scss'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCalendarAlt } from '@fortawesome/free-solid-svg-icons';
import { faSearch } from '@fortawesome/free-solid-svg-icons';
import { faBars, faTimes } from '@fortawesome/free-solid-svg-icons';
import navbarlogo from '../../assets/img/navbarlogo.png';
import { NavLink, useNavigate, useLocation } from "react-router-dom";

const Header = () => {
  const navigate = useNavigate();
  const [isNavOpen, setIsNavOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false); 

  useEffect(() => {
    const token = localStorage.getItem('token'); // Modify this based on your authentication setup
    setIsLoggedIn(!!token);
  }, []);

  const handleLogout = () => {
    // Clear token from localStorage and reset authentication status
    localStorage.removeItem('token');
    setIsLoggedIn(false);
    navigate('/');
  
    // Perform any other necessary cleanup or navigation
  };
  

  const location = useLocation();
  const toggleNav = () => {
    setIsNavOpen(!isNavOpen);
  };



  const handleSearch = () => {
    if (searchTerm.trim() !== '') {
      navigate(`/search?query=${encodeURIComponent(searchTerm)}`);
    }
  };

  const handleInputChange = (e) => {
    setSearchTerm(e.target.value);
  };

  const handleSearchButton = () => {
    handleSearch();
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };
  React.useEffect(() => {
    const params = new URLSearchParams(location.search);
    const query = params.get("query");
    setSearchTerm(query || "");
  }, [location.search]);

  const currentDate = new Date();
  const day = currentDate.getDate();
  const month = currentDate.toLocaleString('default', { month: 'long' });
  const year = currentDate.getFullYear();

  return (
    <header>
      <nav>
        <div className='topbar d-flex'>
          <div className='date  d-flex align-items-center'>
            <p className='mb-0'><FontAwesomeIcon icon={faCalendarAlt} /> {day} {month} {year}</p>
          </div>
          <div className='search'>
            <div className='search-input' onClick={handleSearch}>
              <input type="text"
                value={searchTerm}
                onChange={handleInputChange}
                onKeyDown={handleKeyDown}
                placeholder="Search..." />
              <FontAwesomeIcon
                icon={faSearch}
                className='p-0'
                onClick={handleSearchButton}
              />
            </div>
            <p className='mb-0'>Our Newsletter</p>
          </div>
        </div>
        <nav className="navbar navbar-expand-md">
          <div className="container-fluid p-0">
            <NavLink className="navbar-brand" to="/"> <img src={navbarlogo} /></NavLink>
            <button
              className="navbar-toggler"
              type="button"
              onClick={toggleNav}
              aria-expanded={isNavOpen}
              aria-label="Toggle navigation"
            >
              <FontAwesomeIcon icon={isNavOpen ? faTimes : faBars} style={{ color: 'White', fontSize: '24px', border: '0px' }} />
            </button>
            <div className={`collapse navbar-collapse ${isNavOpen ? 'show' : ''}`} id="navbarTogglerDemo01">
              <ul className="navbar-nav ms-auto mb-2 mb-lg-0">
                <li className="nav-item">
                  <NavLink className="nav-link" aria-current="page" to="/" >Home</NavLink>

                </li>
                <li className="nav-item">
                  <NavLink className="nav-link" to="/events">Events</NavLink>
                </li>
                <li className="nav-item">
                  <NavLink className="nav-link" to="/venues">Venues</NavLink>
                </li>
              </ul>
              {!isLoggedIn ? (
                <NavLink className='nav-btn' to="/sign-in">Sign In</NavLink>
              ) : (
                <NavLink className='nav-btn' onClick={handleLogout}>Logout</NavLink>
              )}
            </div>
          </div>
        </nav>
      </nav>
    </header>
  )
}

export default Header;
